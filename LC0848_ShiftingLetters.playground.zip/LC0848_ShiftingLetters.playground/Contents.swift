/*
 You are given a string s of lowercase English letters and an integer array shifts of the same length.
 
 Call the shift() of a letter, the next letter in the alphabet, (wrapping around so that 'z' becomes 'a').
 
 For example, shift('a') = 'b', shift('t') = 'u', and shift('z') = 'a'.
 Now for each shifts[i] = x, we want to shift the first i + 1 letters of s, x times.
 
 Return the final string after all such shifts to s are applied.
 
 
 
 Example 1:
 Input: s = "abc", shifts = [3,5,9]
 Output: "rpl"
 Explanation: We start with "abc".
 After shifting the first 1 letters of s by 3, we have "dbc".
 After shifting the first 2 letters of s by 5, we have "igc".
 After shifting the first 3 letters of s by 9, we have "rpl", the answer.
 
 Example 2:
 Input: s = "aaa", shifts = [1,2,3]
 Output: "gfd"
 
 
 Constraints:
 
 1 <= s.length <= 105
 s consists of lowercase English letters.
 shifts.length == s.length
 0 <= shifts[i] <= 109
 */


import Foundation

// Timeout...
/*
class Solution {
    static let letters: [Character] = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    
    var letterIndexDictionary: [Character: Int] = {
        var _letterIndexDictionary: [Character: Int] = [:]
        for i in 0..<letters.count {
            _letterIndexDictionary[letters[i]] = i
        }
        
        return _letterIndexDictionary
    } ()
    
    func shiftingLetters(_ s: String, _ shifts: [Int]) -> String {
        let sArray = Array(s)
        var sArrayShifted: [Character] = Array.init(repeating: "@", count: sArray.count)
        var calculatedShifts: [Int] = Array(repeating: 0, count: shifts.count)
        for i in 0..<shifts.count {
            for j in 0...i {
                calculatedShifts[j] += shifts[i]
            }
        }
        for i in 0..<sArray.count {
            sArrayShifted[i] = shiftingLetter(sArray[i], shift: calculatedShifts[i])
        }
        
        return String(sArrayShifted)
    }
    
    private func shiftingLetter(_ letter: Character, shift: Int) -> Character {
        let shiftedIndex = (letterIndexDictionary[letter] ?? 0) + shift
        return Solution.letters[wrappingAround(with: shiftedIndex)]
    }
    
    private func wrappingAround(with shift: Int) -> Int {
        let wrappedShift = shift % 26
        return wrappedShift
    }
}

let solution = Solution()
solution.shiftingLetters("abc", [3,5,9])  //rpl
solution.shiftingLetters("aaa", [1,2,3])  //gfd
solution.shiftingLetters("bad", [10,20,30])  //jyh
 */

class Solution {
    func shiftingLetters(_ S: String, _ shifts: [Int]) -> String {
        var arrS = Array(S)
        var i:Int = shifts.count - 1
        var m:Int = 0
        while(i >= 0) {
            m += shifts[i]
            arrS[i] = (((arrS[i].ascii - 97) + m) % 26 + 97).ASCII
            i -= 1
            m %= 26
        }
        return String(arrS)
    }
}

//Character扩展
extension Character {
  //Character转ASCII整数值(定义小写为整数值)
   var ascii: Int {
       get {
           return Int(self.unicodeScalars.first?.value ?? 0)
       }
    }
}

//Int扩展
extension Int {
    //Int转Character,ASCII值(定义大写为字符值)
    var ASCII:Character {
        get {return Character(UnicodeScalar(self)!)}
    }
}

let solution = Solution()

solution.shiftingLetters("abc", [3,5,9])  //rpl
solution.shiftingLetters("aaa", [1,2,3])  //gfd
solution.shiftingLetters("bad", [10,20,30])  //jyh
