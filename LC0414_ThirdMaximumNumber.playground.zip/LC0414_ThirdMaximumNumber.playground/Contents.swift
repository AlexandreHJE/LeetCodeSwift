/*
 Given an integer array nums, return the third distinct maximum number in this array. If the third maximum does not exist, return the maximum number.

  

 Example 1:

 Input: nums = [3,2,1]
 Output: 1
 Explanation:
 The first distinct maximum is 3.
 The second distinct maximum is 2.
 The third distinct maximum is 1.
 Example 2:

 Input: nums = [1,2]
 Output: 2
 Explanation:
 The first distinct maximum is 2.
 The second distinct maximum is 1.
 The third distinct maximum does not exist, so the maximum (2) is returned instead.
 Example 3:

 Input: nums = [2,2,3,1]
 Output: 1
 Explanation:
 The first distinct maximum is 3.
 The second distinct maximum is 2 (both 2's are counted together since they have the same value).
 The third distinct maximum is 1.
  

 Constraints:

 1 <= nums.length <= 104
 -231 <= nums[i] <= 231 - 1
 */

import Foundation

class Solution {
    func thirdMax(_ nums: [Int]) -> Int {
        var (num0, num1, num2) = (Int.min, Int.min, Int.min)
        nums.forEach({
            if $0 == num0 || $0 == num1 || $0 == num2 {
                //Do nothing...
            } else if $0 > num0 {
                (num0, num1, num2) = ($0, num0, num1)
            } else if $0 > num1 {
                (num0, num1, num2) = (num0, $0, num1)
            } else if $0 > num2 {
                (num0, num1, num2) = (num0, num1, $0)
            }
        })
        return num2 == Int.min ? num0 : num2
    }
}


