/*
 Given an array of integers nums which is sorted in ascending order, and an integer target, write a function to search target in nums. If target exists, then return its index. Otherwise, return -1.

 You must write an algorithm with O(log n) runtime complexity.

  

 Example 1:

 Input: nums = [-1,0,3,5,9,12], target = 9
 Output: 4
 Explanation: 9 exists in nums and its index is 4
 Example 2:

 Input: nums = [-1,0,3,5,9,12], target = 2
 Output: -1
 Explanation: 2 does not exist in nums so return -1
  

 Constraints:

 1 <= nums.length <= 104
 -104 < nums[i], target < 104
 All the integers in nums are unique.
 nums is sorted in ascending order.

 */

import Foundation

/*
 // array empty
        guard !nums.isEmpty else { return -1 }

        // only one element in array and target matched
        if nums.count == 1 && target == nums[0] {
            return nums.firstIndex(of: target)!
        }

        guard nums.count > 1 else { return -1 }
        
        var left = 0
        var right = nums.count
        
        while left < right {
            
            let middle = left + ((right - left) >> 1)
            
            if target < nums[middle] {
                right = middle
            }else if target > nums[middle] {
                left = middle + 1
            }else{
                return middle
            }
        }
        
        return -1
        
    }
 */
func search(_ nums: [Int], _ target: Int) -> Int {
    guard nums.count > 0 else { return -1 }
    if nums.count == 1 {
        if nums[0] == target {
            return 0
        } else {
            return -1
        }
    }
    var result: Int = -1
    var leftPointer: Int = 0
    var rightPointer: Int = nums.count - 1
    while rightPointer > leftPointer {
        let middlePointer: Int = (leftPointer + rightPointer)/2
        if nums[middlePointer] == target {
            result = middlePointer
            break
        } else {
            if nums[middlePointer] > target {
                rightPointer = middlePointer
            } else {
                leftPointer = middlePointer
            }
        }
        if leftPointer == rightPointer - 1 {
            break
        }
    }
    
    return result
}

//search([-1,0,3,5,9,12], 9)
search([-1,0,3,5,9,12], 2)
