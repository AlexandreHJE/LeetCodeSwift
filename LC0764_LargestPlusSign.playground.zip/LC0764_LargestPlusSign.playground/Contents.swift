/*
 In a 2D grid from (0, 0) to (n-1, n-1), every cell contains a 1, except those cells in the given list mines which are 0. What is the largest axis-aligned plus sign of 1s contained in the grid? Return the order of the plus sign. If there is none, return 0.
 
 An "axis-aligned plus sign of 1s of order k" has some center grid[x][y] = 1 along with 4 arms of length k-1 going up, down, left, and right, and made of 1s. This is demonstrated in the diagrams below. note that there could be 0s or 1s beyond the arms of the plus sign, only the relevant area of the plus sign is checked for 1s.
 
 Examples of Axis-Aligned Plus Signs of Order k:
 
 Order 1:
 000
 010
 000
 
 Order 2:
 00000
 00100
 01110
 00100
 00000
 
 Order 3:
 0000000
 0001000
 0001000
 0111110
 0001000
 0001000
 0000000
 Example 1:
 
 Input: n = 5, mines = [[4, 2]]
 Output: 2
 Explanation:
 11111
 11111
 11111
 11111
 11011
 In the above grid, the largest plus sign can only be order 2.  One of them is marked in bold.
 Example 2:
 
 Input: n = 2, mines = []
 Output: 1
 Explanation:
 There is no plus sign of order 2, but there is of order 1.
 Example 3:
 
 Input: n = 1, mines = [[0, 0]]
 Output: 0
 Explanation:
 There is no plus sign, so return 0.
 note:
 
 n will be an integer in the range [1, 500].
 mines will have length at most 5000.
 mines[i] will be length 2 and consist of integers in the range [0, n-1].
 (Additionally, programs submitted in C, C++, or C# will be judged with a slightly smaller time limit.)
 2D grid in a size in (0, 0) to (n-1, n-1)gridIn addition tominesThe unit given in0Every other unit is1. Grid included1What is the maximum axis of Qida? Returns the order of the plus sign. Returns 0 if the plus sign is not found.
 
 A k "1Composed "Axisymmetric" plus sign has a central gridgrid[x][y] = 1And 4 from the center, down, left, to right, length isk-1By1Composed arm. The example of the K "step" axis symmetric "plus sign is given below. note that only the grid of the plus sign is 1, and other grids may be 0 or 1.
 
 K-step axis symmetrical logo example:
 
 Step 1:
 000
 010
 000
 Step 2:
 00000
 00100
 01110
 00100
 00000
 Step 3:
 0000000
 0001000
 0001000
 0111110
 0001000
 0001000
 0000000
 Example 1
 
 Enter: n = 5, mines = [[4, 2]]
 Output: 2
 Explanation:
 11111
 11111
 11111
 11111
 11011
 In the above grid, the maximum plus sign is only 2. A logo is already marked in the figure.
 Example 2:
 
 Enter: n = 2, mines = []
 Output: 1
 Explanation:
 11
 11
 There is no 2nd order sign, there is a 1st order sign.
 Example 3:
 
 Enter: n = 1, mines = [[0, 0]]]]
 Output: 0
 Explanation:
 0
 no plus sign, return 0.
 prompt:
 
 IntegernRange:[1, 500].
 minesThe maximum length is5000.
 mines[i]It is 2 in length 2[0, n-1]The number of numbers.
 (In addition, using C, C ++, or C # programming will be determined with a slight time limit.)
 
 Original LeetCode content:
 
 You are given an integer n. You have an n x n binary grid grid with all values initially 1's except for some indices given in the array mines. The ith element of the array mines is defined as mines[i] = [xi, yi] where grid[xi][yi] == 0.
 
 Return the order of the largest axis-aligned plus sign of 1's contained in grid. If there is none, return 0.
 
 An axis-aligned plus sign of 1's of order k has some center grid[r][c] == 1 along with four arms of length k - 1 going up, down, left, and right, and made of 1's. note that there could be 0's or 1's beyond the arms of the plus sign, only the relevant area of the plus sign is checked for 1's.
 
 Constraints:
 
 1 <= n <= 500
 1 <= mines.length <= 5000
 0 <= xi, yi < n
 All the pairs (xi, yi) are unique.
 
 */


import Foundation

class Solution {
    func orderOfLargestPlusSign(_ n: Int, _ mines: [[Int]]) -> Int {
        var res:Int = 0
        var dp:[[Int]] = [[Int]](repeating:[Int](repeating:n,count:n),count:n)
        for mine in mines {
            dp[mine[0]][mine[1]] = 0
        }

        for i in 0..<n {
            var l:Int = 0
            var r:Int = 0
            var u:Int = 0
            var d:Int = 0
            var j:Int = 0
            var k:Int = n - 1
            while(j < n) {
                l = dp[i][j] != 0 ? l + 1 : 0
                dp[i][j] = min(dp[i][j],l)
                u = dp[j][i] != 0 ? u + 1 : 0
                dp[j][i] = min(dp[j][i],u)
                r = dp[i][k] != 0 ? r + 1 : 0
                dp[i][k] = min(dp[i][k],r)
                d = dp[k][i] != 0 ? d + 1 : 0
                dp[k][i] = min(dp[k][i],d)
                
                j += 1
                k -= 1
            }
        }
        for k in 0..<(n * n) {
            res = max(res, dp[k / n][k % n])
        }
        return res
    }
}

let solution = Solution()

print(solution.orderOfLargestPlusSign(5, [[4, 2]]))
