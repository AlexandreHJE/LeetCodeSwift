/*
 
 Given an integer n, add a dot (".") as the thousands separator and return it in string format.

  

 Example 1:

 Input: n = 987
 Output: "987"
 Example 2:

 Input: n = 1234
 Output: "1.234"
 Example 3:

 Input: n = 123456789
 Output: "123.456.789"
 Example 4:

 Input: n = 0
 Output: "0"
  

 Constraints:

 0 <= n < 2^31
 
 */

import Foundation

func thousandSeparator(_ n: Int) -> String {
    var remainders: [String] = []
    var devidend = n
    while devidend > 999 {
        if devidend % 1000 != 0 {
            remainders.append("\(zeroStuffing(with: devidend % 1000))")
        } else {
            remainders.append("000")
        }
        devidend /= 1000
    }
    
    return "\(devidend)\(covertRemaindersToString(with: remainders))"
}

func zeroStuffing(with number: Int) -> String {
    var result: String = ""
    guard number > 0 else { return "\(-number)" }
    guard number < 1000 else { return "\(number)" }
    switch number {
        case 0...9:
            result = "00\(number)"
            
        case 10...99:
            result = "0\(number)"
            
        case 100...999:
            result = "\(number)"
            
        default:
            result = "\(number)"
    }
    
    return result
}

func covertRemaindersToString(with array: [String]) -> String {
    let reversedArray = array.reversed()
    var result: String = ""
    reversedArray.map({
        result.append(".\($0)")
    })
    
    return result
}

print(thousandSeparator(1000))
print(thousandSeparator(1234))
print(thousandSeparator(10000))
print(thousandSeparator(51040))
print(thousandSeparator(1234567))
